import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface NoticiaDTO {
  id?: number;
  titulo: string;
  contenido: string;
  imagen: string;
  creador: string;
}

@Injectable({ providedIn: 'root' })
export class NoticiaService {
  private readonly baseUrl = '/api/noticia';

  constructor(private http: HttpClient) {}


  getAll(): Observable<NoticiaDTO[]> {
    return this.http.get<NoticiaDTO[]>(`${this.baseUrl}/getall`);
  }


  crearNoticia(noticia: NoticiaDTO): Observable<string> {
    return this.http.post(`${this.baseUrl}/crear`, noticia, {
      responseType: 'text'
    }) as Observable<string>;
  }


  eliminarNoticia(id: number): Observable<string> {
    return this.http.delete(`${this.baseUrl}/deleteById/${id}`, {
      responseType: 'text'
    }) as Observable<string>;
  }


  getRandom(): Observable<NoticiaDTO> {
    return this.http.get<NoticiaDTO>(`${this.baseUrl}/obtenrRandom`);
  }


  findByCreador(creador: string): Observable<NoticiaDTO[]> {
    return this.http.get<NoticiaDTO[]>(`${this.baseUrl}/findByCreador`, {
      params: { creador }
    });
  }
}

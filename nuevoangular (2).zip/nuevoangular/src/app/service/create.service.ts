import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environment/environment';

export interface CreateRequest {
  username: string;
  password: string;
  role: 'ADMIN' | 'EDITOR' | 'VISITANTE';
}

@Injectable({ providedIn: 'root' })
export class CreateService {
  private readonly base = `${environment.api}/auth`;

  constructor(private http: HttpClient) {}


  createUser(data: CreateRequest): Observable<string> {
    const body: CreateRequest = {
      username: (data.username || '').trim(),
      password: (data.password || '').trim(),
      role: data.role
    };


    return this.http.post(`${this.base}/register`, body, {
      responseType: 'text'
    }) as Observable<string>;
  }
}

import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environment/environment';

export interface UsuarioCreateDTO {
  nombre: string;
  correo: string;
  contrasena: string;
  rol: string;
  verified?: boolean;
}

@Injectable({ providedIn: 'root' })
export class ApiService {
  private base = environment.api;

  constructor(private http: HttpClient) {}


  crearUsuario(usuario: UsuarioCreateDTO): Observable<any> {
    return this.http.post(`${this.base}/usuario/createjson`, usuario);
  }


  auth(correo: string, contrasena: string): Observable<string> {
    const params = new HttpParams()
      .set('correo', correo)
      .set('contrasena', contrasena);
    return this.http.post(`${this.base}/auth/login`, null, { params, responseType: 'text' });
  }
}

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-create',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './create.html',
  styleUrls: ['./create.css']
})
export class Create {
  username = '';
  password = '';
  rol = '';
  mensajeOk = '';
  mensajeError = '';

  constructor(
    private http: HttpClient,
    private router: Router
  ) {}

  onCreate(): void {
    this.mensajeOk = '';
    this.mensajeError = '';

    const body = {
      username: this.username.trim(),
      password: this.password.trim(),
      role: this.rol
    };

    this.http.post('/api/auth/register', body, {
      responseType: 'text' as 'json'
    }).subscribe({
      next: (res) => {
        this.mensajeOk = 'Usuario creado exitosamente. Redirigiendo al login...';


        this.username = '';
        this.password = '';
        this.rol = '';


        setTimeout(() => this.router.navigate(['/login']), 1500);
      },
      error: (err) => {
        this.mensajeError = err?.error || ' Error al registrar usuario.';
      }
    });
  }
}

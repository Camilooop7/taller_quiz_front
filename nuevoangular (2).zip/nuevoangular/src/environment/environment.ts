export const environment = {
  production: false,
  api: '/api'
};

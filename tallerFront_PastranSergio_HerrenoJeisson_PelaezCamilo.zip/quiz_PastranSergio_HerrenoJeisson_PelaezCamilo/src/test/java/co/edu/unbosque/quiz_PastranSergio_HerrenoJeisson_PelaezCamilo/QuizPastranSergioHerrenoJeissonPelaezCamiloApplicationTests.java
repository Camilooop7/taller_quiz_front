package co.edu.unbosque.quiz_PastranSergio_HerrenoJeisson_PelaezCamilo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizPastranSergioHerrenoJeissonPelaezCamiloApplicationTests {

	@Test
	void contextLoads() {
	}

}

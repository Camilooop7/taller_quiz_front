import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environment/environment';
import { Observable, tap } from 'rxjs';

export interface LoginRequest {
  username: string;
  password: string;
}

export interface LoginResponse {
  token: string;
  role: string;
}

interface UserSession {
  username: string;
  role: string;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly base = `${environment.api}/auth`;
  private readonly TOKEN_KEY = 'app.token';
  private readonly USER_KEY = 'app.user';

  constructor(private http: HttpClient) {}


  login(data: LoginRequest): Observable<LoginResponse> {
    const body: LoginRequest = {
      username: (data.username || '').trim(),
      password: (data.password || '').trim()
    };

    return this.http.post<LoginResponse>(`${this.base}/login`, body).pipe(
      tap(res => this.saveSession(res))
    );
  }


  private saveSession(res: LoginResponse): void {
    if (!res?.token) return;

    localStorage.setItem(this.TOKEN_KEY, res.token);

    const user: UserSession = {
      username: this.decodeUsernameFromToken(res.token) || 'unknown',
      role: res.role || 'USER'
    };
    localStorage.setItem(this.USER_KEY, JSON.stringify(user));
  }


  private decodeUsernameFromToken(token: string): string | null {
    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload?.sub || null;
    } catch {
      return null;
    }
  }


  get token(): string | null {
    return localStorage.getItem(this.TOKEN_KEY);
  }


  get user(): UserSession | null {
    const raw = localStorage.getItem(this.USER_KEY);
    try {
      return raw ? (JSON.parse(raw) as UserSession) : null;
    } catch {
      return null;
    }
  }


  isLogged(): boolean {
    return !!this.token;
  }


  hasRole(role: string): boolean {
    const u = this.user;
    if (!u?.role) return false;
    return u.role.toUpperCase() === role.toUpperCase();
  }


  logout(): void {
    localStorage.removeItem(this.TOKEN_KEY);
    localStorage.removeItem(this.USER_KEY);
  }
}

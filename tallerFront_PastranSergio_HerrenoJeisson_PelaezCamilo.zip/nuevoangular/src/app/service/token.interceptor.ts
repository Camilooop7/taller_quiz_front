
import { Injectable } from '@angular/core';
import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpErrorResponse
} from '@angular/common/http';
import { Observable, catchError, throwError } from 'rxjs';
import { Router } from '@angular/router';
import { AuthService } from './auth.service';
import { environment } from '../../environment/environment';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {

  constructor(
    private auth: AuthService,
    private router: Router
  ) {}

  intercept(req: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    const apiBase = (environment.api || '/api').replace(/\/+$/, ''); // sin slash final
    const absoluteApi = apiBase.startsWith('http')
      ? apiBase
      : `${location.origin}${apiBase}`;


    const isApiCall =
      req.url.startsWith('/api') ||               // típico con proxy Angular
      req.url.startsWith(apiBase) ||
      req.url.startsWith(absoluteApi);


    const isPublic =
      req.method === 'OPTIONS' ||
      (isApiCall && (
        req.url.includes('/auth/login') ||
        req.url.includes('/auth/register') ||
        req.url.includes('/usuario/createjson') ||
        req.url.includes('/usuario/verificar/')
      ));

    let request = req;


    const token = this.auth.token;
    if (isApiCall && !isPublic && token && !request.headers.has('Authorization')) {
      request = request.clone({
        setHeaders: { Authorization: `Bearer ${token}` }
      });
    }


    if (
      isApiCall &&
      !request.headers.has('Content-Type') &&
      request.body &&
      !(request.body instanceof FormData) &&
      (request.method === 'POST' || request.method === 'PUT' || request.method === 'PATCH')
    ) {
      request = request.clone({
        setHeaders: { 'Content-Type': 'application/json' }
      });
    }


    if (isApiCall && !request.headers.has('Accept')) {
      request = request.clone({
        setHeaders: { Accept: 'application/json' }
      });
    }

    return next.handle(request).pipe(
      catchError((err: unknown) => {
        if (err instanceof HttpErrorResponse) {
          const current = this.router.url || '/';


          if (err.status === 401) {
            this.auth.logout();


            if (
              !current.startsWith('/login') &&
              !current.startsWith('/create')
            ) {
              this.router.navigateByUrl(
                `/login?returnUrl=${encodeURIComponent(current)}`
              );
            }
          }


          if (err.status === 403) {
            const atPublic =
              current.startsWith('/login') ||
              current.startsWith('/create');

            if (!atPublic && !current.startsWith('/menu')) {
              this.router.navigateByUrl('/menu');
            }
          }
        }

        return throwError(() => err);
      })
    );
  }
}

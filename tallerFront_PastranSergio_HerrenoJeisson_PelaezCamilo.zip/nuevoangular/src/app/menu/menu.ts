import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { NoticiaService } from '../service/noticia.service';

@Component({
  selector: 'app-menu',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './menu.html',
  styleUrls: ['./menu.css']
})
export class Menu {

  titulo = '';
  descripcion = '';
  url = '';
  creador = '';


  mensajeOk = '';
  mensajeError = '';

  constructor(private noticiaService: NoticiaService, private router: Router) {}


  crearNoticia(): void {
    this.mensajeOk = '';
    this.mensajeError = '';

    const noticia = {
      titulo: this.titulo,
      contenido: this.descripcion,localizacion: "a",
      imagen: this.url,
      creador: this.creador
    };

    this.noticiaService.crearNoticia(noticia).subscribe({
      next: (res) => {
        this.mensajeOk = res;
        this.limpiarFormulario();
      },
      error: (err) => {
        this.mensajeError = err?.error || 'Error al crear la noticia';
      }
    });
  }


  limpiarFormulario(): void {
    this.titulo = '';
    this.descripcion = '';
    this.url = '';
    this.creador = '';
  }


  verNoticias(): void {
    this.router.navigate(['/noticias']);
  }
}

import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { NoticiaService, NoticiaDTO } from '../service/noticia.service';
import { AuthService } from '../service/auth.service';

@Component({
  selector: 'app-notice',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './notice.html',
  styleUrls: ['./notice.css']
})
export class Notice implements OnInit {
  noticias: NoticiaDTO[] = [];
  noticiasFiltradas: NoticiaDTO[] = [];
  randomNoticia?: NoticiaDTO;
  mensajeEliminar = '';
  mensajeRandom = '';
  filtroCreador = '';

  isInvitado = false;

  constructor(
    private noticiaService: NoticiaService,
    private router: Router,
    private auth: AuthService
  ) {}

  ngOnInit(): void {

    this.isInvitado = localStorage.getItem('modoInvitado') === 'true';


    if (!this.isInvitado && this.auth.isLogged()) {
      this.cargarNoticias();
    }
  }

  cargarNoticias(): void {
    this.noticiaService.getAll().subscribe({
      next: (data) => {
        this.noticias = data;
        this.noticiasFiltradas = [...this.noticias];
      },
      error: () => {
        this.mensajeEliminar = 'Error al cargar las noticias.';
      }
    });
  }

  filtrarNoticias(): void {
    const filtro = this.filtroCreador.toLowerCase();
    this.noticiasFiltradas = this.noticias.filter(n =>
      n.creador.toLowerCase().includes(filtro)
    );
  }

  verRandom(): void {
    this.mensajeRandom = '';
    this.noticiaService.getRandom().subscribe({
      next: (noticia) => {
        this.randomNoticia = noticia;
      },
      error: () => {
        this.mensajeRandom = 'No hay noticias disponibles.';
      }
    });
  }

  eliminarNoticia(noticia: NoticiaDTO): void {
    if (this.isInvitado || !noticia.id) return;

    this.noticiaService.eliminarNoticia(noticia.id).subscribe({
      next: (msg) => {
        this.mensajeEliminar = msg;
        this.cargarNoticias();
      },
      error: () => {
        this.mensajeEliminar = 'Error al eliminar la noticia.';
      }
    });
  }

  puedeEliminar(): boolean {
    return !this.isInvitado;
  }

  regresar(): void {


    if (this.isInvitado) {
      localStorage.removeItem('modoInvitado');
      this.router.navigate(['/login']);
    } else {
      this.router.navigate(['/menu']);
    }
  }
}

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { AuthService } from '../service/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})
export class Login {
  username = '';
  password = '';
  mensajeError = '';

  constructor(
    private auth: AuthService,
    private router: Router
  ) {}

  // 🔹 Iniciar sesión normal
  onLogin(): void {
    this.mensajeError = '';

    this.auth.login({
      username: this.username,
      password: this.password
    }).subscribe({
      next: () => {
        localStorage.removeItem('modoInvitado');
        this.router.navigate(['/menu']);
      },
      error: (err: HttpErrorResponse) => {
        this.mensajeError =
          (typeof err.error === 'string'
            ? err.error
            : err.error?.message) ||
          'Credenciales inválidas o error en el servidor.';
      }
    });
  }


  verComoInvitado(): void {
    this.auth.logout();
    localStorage.setItem('modoInvitado', 'true');
    this.router.navigate(['/notice']);
  }
}

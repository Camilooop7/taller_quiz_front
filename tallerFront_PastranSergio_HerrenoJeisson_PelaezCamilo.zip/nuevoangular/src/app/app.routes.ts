import { Routes } from '@angular/router';
import { Create } from './create/create';
import { Login } from './login/login';
import { Menu } from './menu/menu';
import { Notice} from './notice/notice';


export const routes: Routes = [
  { path: '', redirectTo: 'create', pathMatch: 'full' },
  { path: 'create', component: Create },
  { path: 'login', component: Login },
  { path: 'menu', component: Menu, },
  { path: 'notice', component: Notice,},
  { path: '**', redirectTo: 'create' },

];
